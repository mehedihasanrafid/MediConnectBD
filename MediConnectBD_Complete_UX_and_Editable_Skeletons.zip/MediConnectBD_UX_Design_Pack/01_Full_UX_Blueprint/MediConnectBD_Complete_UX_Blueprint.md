# MediConnectBD - Complete UX Skeleton & Page Workflow Blueprint
**Document:** Full UX specification | **Scope:** Public, patient, doctor, verification and supporting pages | **Time zone:** Asia/Dhaka

> All person, appointment, financial and clinical data shown in diagrams are structural placeholders. Live interfaces must use authorized APIs and actual transaction states. This document specifies UX design; it does not claim the features are implemented.

## 1. Overall UX architecture
Four related environments share one calm visual language: the **Public website** for discovery; **Patient account** for family, bookings, payments and records; **Doctor workspace** for clinical and operational workflow; **Admin workspace** for verification and platform operations. Do not treat administrative access as clinical authorization.

| Shell | Header | Navigation | Main content | Footer |
|---|---|---|---|---|
| Public | Logo, navigation, account | Horizontal desktop/menu mobile | 1200-1280px max width | Full site footer |
| Booking | Minimal logo, back, support | Stepper | Form plus booking summary | Minimal |
| Patient account | Account header | Sidebar or compact mobile navigation | Appointments, family, records | Optional |
| Doctor workspace | Compact utility header | Left sidebar or mobile drawer | Task-oriented pages | No full public footer |
| Admin workspace | Restricted utility header | Role-specific sidebar | Verification and permitted operations | No public footer |

**Visual foundation:** White/cool-gray surfaces, deep navy type, aqua-teal actions, small Lucide-style icons, crisp borders, restrained shadows, Bangladesh-appropriate medical photography and genuine data only. Public visitors do not see a theme selector; authenticated account settings may contain one when supported.

## 2. Global header, navbar and utility components
### Public header
`[Logo: MediConnectBD] [Find Doctors] [Specialties] [How It Works] [Help] [Sign In/Register or Account]`

Logo returns home; Find Doctors opens P01; Specialty shortcuts open a filtered P01; signed-in avatar opens appointments, family, account settings and sign-out. On mobile, collapse links into a menu drawer. Do **not** use a shopping-cart icon: booking uses a Booking Summary card rather than product-cart semantics.

### Doctor workspace navigation
`[Today] [Appointments] [Schedule & Leave] [Consultations] [Prescriptions] [Earnings] [Profile & Chambers] [Settings]`

Utility header includes page title, sidebar menu, avatar, help and notifications only when implemented. Appointment search must not enable unrestricted access to patient clinical records.

### Reusable UI inventory
| Component | Primary use |
|---|---|
| Breadcrumbs | Public discovery and detail pages |
| Search + filter sidebar/mobile drawer | Doctor directory; queue search |
| Tabs/status chips | Profile sections, bookings, queue |
| Date selector and slot chips | Availability, schedules, booking |
| Booking Summary card | Checkout and payment review |
| Skeleton / empty / error states | All API-backed pages |
| Toast vs inline alert | Noncritical save vs actionable validation/error |
| Confirmation modal | Cancellation, discard, actual issuance decision |
| Detail/history drawer | Context without losing queue/consultation |
| Stepper | Booking and doctor verification |
| Pagination | Directory and transaction ledger |
| Actual-data charts | Earnings only in initial product |
| Accessible uploader | Doctor credentials and patient documents |

Use modals for short consequential decisions, drawers for context, and full pages for long forms. Keep accessible labels, focus states and appropriate target sizes.

## 3. Page inventory and routes
| ID | Page | Route | Role |
|---|---|---|---|
| P01 | Public doctor directory | `/doctors` | Public |
| P02 | Public doctor profile | `/doctors/:id` | Public |
| P03 | Slot selection, booking and checkout | `/booking/:doctorId` | Visitor then Patient |
| D01 | Doctor registration and verification | `/doctor/onboarding` | Doctor applicant |
| D02 | Doctor profile and chamber setup | `/doctor/profile` | Approved doctor or limited applicant draft |
| D03 | Doctor schedule and leave management | `/doctor/schedule` | Verified doctor |
| D04 | Doctor daily dashboard | `/doctor/dashboard` | Verified doctor |
| D05 | Doctor appointment queue | `/doctor/appointments` | Verified doctor |
| D06 | Patient-history drawer | `Context within /doctor/consultations/:id` | Authorized clinician |
| D07 | Video consultation workspace | `/doctor/consultations/:id` | Assigned doctor; patient has own waiting/join UI |
| D08 | Prescription builder | `/doctor/consultations/:id/prescription` | Authorized prescribing doctor |
| D09 | Doctor earnings | `/doctor/earnings` | Verified doctor; authorized finance roles separately |

### Supporting routes
| ID | Supporting page | Structural skeleton |
|---|---|---|
| S01 | Sign In / Register | Minimal header -> sign-in form -> recovery/help -> return destination |
| S02 | Family Member Selection | Booking header -> self/family cards -> add person form -> continue |
| S03 | Video Payment | Minimal checkout -> actual payment choices -> fee summary -> authoritative status |
| S04 | Booking Confirmation | Status heading -> verified booking card -> address/video instructions -> action buttons |
| S05 | My Appointments | Patient account nav -> Upcoming/Past/Cancelled -> appointment cards -> detail/actions |
| S06 | Family Management | Account sidebar -> family list/cards -> add/edit -> permission notices |
| S07 | Patient Records | Account header -> encounter tabs -> issued prescriptions -> document viewer |
| S08 | Patient Video Waiting Room | Appointment identity -> device test -> real consent -> join controls |
| S09 | Admin Verification Review | Admin nav -> applicant queue -> submitted documents -> decision panel |
| S10 | Account Settings | Account nav -> profile/security -> language/theme (after login) -> notification prefs |
| S11 | Doctor Verification Status | Applicant header -> status banner -> application summary -> correction requests |
| S12 | Help & Support | Help nav -> FAQ -> issue categories -> contact/ticket history |

## 4. Primary patient journey
**Discover doctor -> Open doctor profile -> Choose chamber/video and API slot -> Request backend hold -> Authenticate -> Choose self/family member -> Review -> Chamber confirm OR Video verified payment -> Confirmation -> Attend -> Authorized records.**

**Slot semantics:** Selected is not held; held is not confirmed. A hold timer exists only after backend-confirmed hold creation and must use actual server expiry. Recheck hold after sign-in. Video booking confirmation requires verified payment and successful booking finalization. If there is uncertainty after payment, show a Pending Confirmation state rather than fake success.

## 5. Full page skeletons and UX contracts
### P01 - Public doctor directory
**Route:** `/doctors` | **Role:** Public | **Pattern:** Search-first marketplace
**Primary user goal:** Search, filter and compare doctors without authentication.

**Desktop wireframe (editable text, conceptual)**
```text
[PUBLIC HEADER: Logo | Find Doctors | Specialties | Login]
[Breadcrumb] [Page Title]
[ Search doctor / specialty ][ Area ][ Search ]
[ Specialty chips ][ Chamber / Video ]
+------------------+----------------------------------+
| FILTERS          | Results # | Sort                 |
| Specialty        | +------------------------------+ |
| Area             | | Photo | Doctor summary       | |
| Mode             | |       | Fees / availability  | |
| Fee              | |       | View profile         | |
| Available date   | +------------------------------+ |
+------------------+----------------------------------+
[Pagination / Load More] [PUBLIC FOOTER]
```

**Desktop content order:**
- Public header, breadcrumb, page heading
- Primary doctor/specialty search + area selector + Search action
- Specialty shortcut chips and mode selector
- Left filter sidebar: specialty, appointment type, district/area, fee, available date
- Results toolbar: real count, applied-filter chips, sort
- Doctor result cards: photograph, name, specialty, actual credentials, location, fees, API availability
- Pagination/Load More backed by API
- Public footer

**Mobile structure:**
- Compact logo/header + menu drawer
- Search bar and quick specialty chips
- Filter button opens full-height drawer; sort remains accessible
- Single-column doctor cards, result pagination
- Footer below results

**Required real information:** Search query; specialty; chamber/video; area; fee range; available date; API result set.
**Primary action:** View Profile
**Secondary actions:** Change filters; sort; clear; specialty browse; Book only for actually available and eligible doctors.
**Connected workflow:** Home/Search -> Filtered results -> Doctor card -> P02 Profile -> P03 Booking.

| UX state / constraint | Specification |
|---|---|
| Loading | Keep filters and text, show result-card skeletons. |
| Empty | No matches: Clear Filters; distinguish empty catalog from filtered results. |
| Error | Unable to load doctors: Retry. Never replace API error with demo doctors. |
| Permission | Public browsing. Route booking to authenticated process. |
| Postpone | Doctor comparison, recommendation AI, favorites, map exploration, advanced ranking. |
| Never simulate | Fake doctor counts, reviews, rankings, availability, BMDC badge, credentials. |

### P02 - Public doctor profile
**Route:** `/doctors/:id` | **Role:** Public | **Pattern:** Profile with sticky booking panel
**Primary user goal:** Assess credentials, practice locations and real availability before booking.

**Desktop wireframe (editable text, conceptual)**
```text
[PUBLIC HEADER] [Breadcrumb]
+--------------------------------+-------------------+
| Photo | Name, specialty        | BOOKING PANEL     |
| Qualifications & registration  | Chamber | Video   |
| [About][Credentials][Chambers] | Chamber selector  |
| Biography                      | Date picker       |
| Credentials                    | Actual slot chips |
| Chamber locations and fees     | Fee / policy      |
| Consultation policy            | [Continue]        |
+--------------------------------+-------------------+
[PUBLIC FOOTER]
```

**Desktop content order:**
- Breadcrumb and public header
- Left: profile identity, actual qualifications and registration data
- Left sections/tabs: About, Qualifications, Chambers, Consultation policy
- Right sticky booking panel: Chamber/Video, chamber selector, date, server slots, fee
- Bottom: footer and supporting navigation

**Mobile structure:**
- Identity card and essential credentials first
- Accordion/sections for qualifications, chambers, policies
- Sticky bottom Book Appointment button opens booking selector
- No permanently sticky desktop-sized availability panel

**Required real information:** Doctor API fields; chambers; modes; fees; policy; published slots.
**Primary action:** Select Appointment / Continue to Booking
**Secondary actions:** Switch mode or chamber; browse qualifications; open location information.
**Connected workflow:** P01 -> P02 -> Mode + location + date -> P03.

| UX state / constraint | Specification |
|---|---|
| Loading | Profile skeleton and separate availability skeleton. |
| Empty | No slots: explain unavailability but keep profile visible. |
| Error | If slot API fails, preserve doctor information and Retry Availability. |
| Permission | Public; booking prompts authentication when required. |
| Postpone | Comparisons, patient Q&A, reviews until genuine review system, external editorial feeds. |
| Never simulate | Invent doctor qualifications, registration, affiliation, rating, slots or verification. |

### P03 - Slot selection, booking and checkout
**Route:** `/booking/:doctorId` | **Role:** Visitor then Patient | **Pattern:** Single guided stepper + booking summary
**Primary user goal:** Secure correct appointment for correct patient with trustworthy confirmation.

**Desktop wireframe (editable text, conceptual)**
```text
[MINIMAL HEADER: Back | Logo | Help]
[1 Slot] -> [2 Sign in] -> [3 Patient] -> [4 Review]
+---------------------------------+-------------------+
| Mode: Chamber / Video           | BOOKING SUMMARY   |
| Choose chamber (when relevant)  | Doctor            |
| Date picker + real slots        | Date / time       |
| Hold state / expiry from server | Patient           |
| Sign in (if required)           | Charges / Total   |
| Self / Family selection         | Hold expiry       |
| Policy + confirmation           +-------------------+
| [Contextual Primary Action]                         |
+-----------------------------------------------------+
[Video requires verified payment before confirmation]
```

**Desktop content order:**
- Minimal booking header with Back and Help
- Step 1 Slot > Step 2 Sign in > Step 3 Patient > Step 4 Review/Pay
- Main panel: mode, chamber, date, actual slots; context changes per step
- Right persistent summary: doctor, mode, chamber, date/time, patient, fee/charges
- Server-confirmed hold expiry and cancellation policy
- Contextual bottom action: Reserve, Continue, Confirm or Pay & Confirm

**Mobile structure:**
- Compact header and step-progress indicator
- One active step at a time
- Collapsible booking summary
- Sticky action only where it does not cover content

**Required real information:** Doctor; mode; chamber; available slot; server hold ID/expiry; identity; family member; charges; actual payment state.
**Primary action:** Reserve slot / Confirm Booking / Pay & Confirm, depending on step
**Secondary actions:** Back; change mode/date/time; choose/add family; cancel booking.
**Connected workflow:** P02 -> Select slot -> Backend hold -> Sign in -> Select patient -> Chamber confirm OR Video verified payment -> Confirmation.

| UX state / constraint | Specification |
|---|---|
| Loading | Separate progress for hold, sign-in, family load, payment and booking finalization. |
| Empty | No slots, no family profiles or unavailable payment method: distinct recovery. |
| Error | Expired hold, slot conflict, payment failure, confirmed payment with booking pending: distinct states. |
| Permission | Final booking requires sign-in; revalidate held slot after auth. Authorized family booking only. |
| Postpone | Coupons, loyalty, stored cards, subscriptions, waitlist, multi-booking checkout. |
| Never simulate | Fake hold countdown, payment success, booking reference, meeting link or confirmed slot. |

### D01 - Doctor registration and verification
**Route:** `/doctor/onboarding` | **Role:** Doctor applicant | **Pattern:** Multi-step verification wizard
**Primary user goal:** Submit professional credentials and track legitimate review.

**Desktop wireframe (editable text, conceptual)**
```text
[DOCTOR ONBOARDING HEADER | Save & Exit]
+-----------------+---------------------------------+
| STEP NAV        | CURRENT STEP FORM               |
| 1 Identity      | Full labels + validation         |
| 2 BMDC details  | BMDC registration data           |
| 3 Qualifications| Certificates upload             |
| 4 Certificates  | Review + declaration            |
| 5 Review        | [Back][Save][Continue/Submit]    |
+-----------------+---------------------------------+
[Status: Draft / Under Review / Changes / Approved]
```

**Desktop content order:**
- Minimal applicant header + Save and Exit
- Progress rail: Identity > BMDC > Qualifications > Certificates > Review
- Main form: labels, validation, guidance and actual upload controls
- Document checklist, review summary and declarations
- Back / Save Draft / Continue / Submit controls

**Mobile structure:**
- One step per screen, compact progress
- Camera/file upload with clear status
- Persistent Save Draft/Continue when safe

**Required real information:** Legal details, contact, BMDC registration info, qualifications, certificates, declarations.
**Primary action:** Submit for Verification
**Secondary actions:** Save draft; replace upload; correct fields; view review status.
**Connected workflow:** Register -> Identity -> BMDC -> Certificates -> Review -> Submit -> Admin decision / correction request.

| UX state / constraint | Specification |
|---|---|
| Loading | Per-document upload progress and submission status. |
| Empty | Document checklist when none uploaded. |
| Error | Unsupported document, duplicate claim, incomplete info, upload failure; preserve draft. |
| Permission | Authenticated applicant only. No live bookability until approved. |
| Postpone | OCR auto-validation, automated approval, external registry checking not implemented. |
| Never simulate | Fake BMDC approval, certificate validation, official status or endorsement. |

### D02 - Doctor profile and chamber setup
**Route:** `/doctor/profile` | **Role:** Approved doctor or limited applicant draft | **Pattern:** Settings navigation + structured editor + public preview
**Primary user goal:** Maintain correct professional information, chambers, modes and fees.

**Desktop wireframe (editable text, conceptual)**
```text
[DOCTOR HEADER + LEFT MAIN SIDEBAR]
[Profile & Practice: Preview | Save]
+-------------+---------------------+--------------+
| SECTIONS    | EDITOR              | PREVIEW      |
| Profile     | Professional info   | Public card  |
| Credentials | Bio / specialties   | No publish   |
| Chambers    | Chamber repeaters   | claim until  |
| Video/Fees  | Addresses and fees  | approved     |
| Publication | [Add chamber]       |              |
+-------------+---------------------+--------------+
```

**Desktop content order:**
- Doctor workspace sidebar and utility header
- Section navigation: Profile, Qualifications, Specialties, Chambers, Video & Fees, Publication
- Main editable form with repeatable chamber cards
- Right public-preview card, not claimed as published
- Save / Submit for review and status indicators

**Mobile structure:**
- Section accordions and full-width forms
- Single chamber edit sheet
- Separate preview route or panel

**Required real information:** Professional identity, approved credentials, biography, chambers/addresses, consultation mode, fees, duration.
**Primary action:** Save Changes / Submit for Review
**Secondary actions:** Add/edit/deactivate chamber; preview public card; adjust fees.
**Connected workflow:** Approved practitioner -> Professional details -> Add chambers and modes -> Set fees -> D03 schedule -> Publish if eligible.

| UX state / constraint | Specification |
|---|---|
| Loading | Per-section saving and profile skeleton. |
| Empty | Add first chamber or configure eligible video mode. |
| Error | Required fields, bad address, fee validation, review conflicts, save failure. |
| Permission | Owner edits allowed fields. Credential changes may require new review. |
| Postpone | Staff scheduling teams, ads, image galleries, external calendars. |
| Never simulate | False hospital affiliation, published status, verified credentials or fees. |

### D03 - Doctor schedule and leave management
**Route:** `/doctor/schedule` | **Role:** Verified doctor | **Pattern:** Weekly calendar + leave exceptions
**Primary user goal:** Publish reliable availability while protecting existing bookings.

**Desktop wireframe (editable text, conceptual)**
```text
[DOCTOR SHELL: Schedule | Save]
[Mode/Chamber][Week][Add hours][Add leave]
+----------------------------------+----------------+
| WEEK CALENDAR                    | RULE EDITOR    |
| Su Mo Tu We Th Fr Sa             | Shift hours    |
| [ ] [ ] [ ] [ ] [ ] [ ] [ ]       | Buffers        |
| [ ] [ ] [ ] [ ] [ ] [ ] [ ]       | Slot duration  |
| Working blocks (real data)       | Leave dates    |
| Existing booked appointment cues | Conflicts      |
+----------------------------------+----------------+
[Preview resulting slots] [Publish if valid]
```

**Desktop content order:**
- Doctor shell, page header and Save action
- Controls: chamber/mode, week selector, Add Hours, Add Leave
- Main seven-day calendar with actual working blocks and existing bookings
- Side panel: shift editor, slot duration, buffers, leave, conflict list
- Preview resulting availability before publish

**Mobile structure:**
- Day tabs + vertical timeline/list
- Full-screen shift/leave editor
- Conflict warnings on same step

**Required real information:** Working-day rules, location/mode, durations, buffers, exceptions, confirmed bookings, Dhaka time.
**Primary action:** Save/Publish Schedule
**Secondary actions:** Copy day; edit hours; add leave; preview slots; resolve conflicts.
**Connected workflow:** Select chamber/mode -> Create hours -> Preview slots -> Resolve conflicts -> Publish -> Handle leave with affected-booking workflow.

| UX state / constraint | Specification |
|---|---|
| Loading | Weekly skeleton and save progress. |
| Empty | No schedule set: Set Working Hours. |
| Error | Overlaps, invalid duration, conflicts with bookings, failed leave submission. |
| Permission | Doctor/explicit scheduler only; approved practitioner required to publish. |
| Postpone | Calendar sync, automatic optimization, waitlists, group scheduling. |
| Never simulate | Invent opening slots, approved leave, cancellations, notifications. |

### D04 - Doctor daily dashboard
**Route:** `/doctor/dashboard` | **Role:** Verified doctor | **Pattern:** Today-first operational dashboard
**Primary user goal:** See next appointment and immediate operational priorities.

**Desktop wireframe (editable text, conceptual)**
```text
[DOCTOR SHELL | Today | Dhaka time]
[KPI Scheduled] [KPI Waiting] [KPI Done] [KPI Tasks]
+---------------------------------------------------+
| NEXT APPOINTMENT                                  |
| Actual patient, mode, time | [Open/Start]          |
+----------------------------------+----------------+
| TODAY'S QUEUE                    | NEEDS ATTENTION|
| Patient cards / time / status    | Notices        |
| [View all queue]                 | Pending tasks  |
+----------------------------------+----------------+
```

**Desktop content order:**
- Doctor sidebar, utility header, Today heading in Dhaka time
- Four KPI cards: scheduled, waiting (if tracked), completed, action needed
- Large Next Appointment card with actual details and contextual CTA
- Main Today Queue preview
- Side Needs Attention panel, schedule alerts and pending tasks

**Mobile structure:**
- Next appointment first
- Compact queue cards
- Two-across or stacked KPIs; alerts below

**Required real information:** Today schedule, authorized appointment statuses, actual queue and issues.
**Primary action:** Open Next Appointment / View Queue
**Secondary actions:** View schedule; inspect tasks; navigate to earnings.
**Connected workflow:** Login -> Today -> Next appointment -> Queue -> Consultation -> Today refreshed.

| UX state / constraint | Specification |
|---|---|
| Loading | Independent skeletons for KPIs, queue and notices. |
| Empty | No appointments today with View Schedule. |
| Error | Partial API errors shown per widget; unknown count not zero. |
| Permission | Approved doctor; only assigned records. |
| Postpone | Custom widgets, analytics-first charts, physician productivity scores. |
| Never simulate | Fake waiting patients, counts, live presence, revenue or clinical completion. |

### D05 - Doctor appointment queue
**Route:** `/doctor/appointments` | **Role:** Verified doctor | **Pattern:** Timeline/list + contextual details drawer
**Primary user goal:** Process scheduled appointments safely in chronological order.

**Desktop wireframe (editable text, conceptual)**
```text
[DOCTOR SHELL | Appointments | Date picker]
[All][Upcoming][Checked in][In progress][Completed]
[Search queue] [Mode filter]
+----------------------------------+----------------+
| CHRONOLOGICAL QUEUE              | DETAIL DRAWER  |
| Time | Patient | Mode | Status   | Identity       |
| Time | Patient | Mode | Status   | Status         |
| Time | Patient | Mode | Status   | Contextual CTA |
+----------------------------------+----------------+
```

**Desktop content order:**
- Doctor shell + date picker
- Status tabs: All, Upcoming, Checked In, In Progress, Completed, Cancelled
- Search and consultation-mode filters
- Time-ordered rows: time, real patient, mode, status and action
- Right appointment details panel with transition controls

**Mobile structure:**
- Status chips and date selector
- One-column appointment cards
- Full-screen detail sheet with contextual action

**Required real information:** Assigned booking records, patient identity, mode, payment eligibility, check-in and encounter status.
**Primary action:** Start Consultation (only when eligible)
**Secondary actions:** Details; check-in; eligible no-show; cancel and filter as allowed.
**Connected workflow:** Dashboard -> Filter queue -> Appointment details -> Eligible Start -> D07 Consultation -> Update state.

| UX state / constraint | Specification |
|---|---|
| Loading | Queue row skeletons without changing filters. |
| Empty | No records for chosen date/filter. |
| Error | Conflicting status transition or retrieval failure; show server state. |
| Permission | Assigned doctor; staff only expressly delegated metadata permissions. |
| Postpone | Drag reorder, AI prioritization, predictive wait, automatic check-in. |
| Never simulate | Fake check-in/no-show/queue change or consultation start. |

### D06 - Patient-history drawer
**Route:** `Context within /doctor/consultations/:id` | **Role:** Authorized clinician | **Pattern:** Right drawer; full screen on mobile
**Primary user goal:** Inspect relevant authorized historical records without losing encounter context.

**Desktop wireframe (editable text, conceptual)**
```text
[CONSULTATION VIEW: background]
                      +-----------------------------+
                      | PATIENT HISTORY [Close]     |
                      | Patient + encounter ID      |
                      | [Summary][Visits][Meds]     |
                      | [Allergies][Documents]      |
                      | Authorized record cards     |
                      | [Open detail]                |
                      +-----------------------------+
```

**Desktop content order:**
- Patient and encounter identity header
- Drawer close/back control
- Tabs: Overview, Visits, Medicines, Allergies, Documents
- Authorized clinical record cards with source dates
- Select record opens detail; return to encounter

**Mobile structure:**
- Full-screen history sheet with persistent patient header
- Section tabs, expandable records, Back to Consultation

**Required real information:** Patient identity, access scope/consent, recorded history, medicines, allergies, records, reports.
**Primary action:** Open Relevant Record
**Secondary actions:** Switch sections; expand document; close drawer.
**Connected workflow:** Authorized consultation -> Open history -> Verify scope -> Inspect records -> Close -> Continue notes.

| UX state / constraint | Specification |
|---|---|
| Loading | Section-specific skeletons. |
| Empty | No accessible records found (not no medical history). |
| Error | Permission denied, consent changed or report unavailable. |
| Permission | Only authorized clinicians with appropriate encounter scope; no default admin notes access. |
| Postpone | Inter-hospital integrations, AI summaries, automatic problem lists. |
| Never simulate | Fabricated diagnoses/allergies/records/consent or access rights. |

### D07 - Video consultation workspace
**Route:** `/doctor/consultations/:id` | **Role:** Assigned doctor; patient has own waiting/join UI | **Pattern:** Video + clinical split screen
**Primary user goal:** Conduct actual consultation and document clinical encounter.

**Desktop wireframe (editable text, conceptual)**
```text
[CONSULTATION HEADER: patient / mode / status]
+---------------------------------+------------------+
| VIDEO VIEW                      | CLINICAL PANEL   |
| Actual session / participant    | Notes | History  |
|                                 | Prescription     |
| [Mic][Camera][Audio][Hang up]   | Clinical form    |
| Connection and device state     | [Save Draft]     |
+---------------------------------+------------------+
[Complete encounter only on verified eligible state]
```

**Desktop content order:**
- Patient/appointment header + true session status
- Large remote video area, local preview and functional device controls
- Right clinical panel tabs: Notes, History, Prescription
- Draft-safe notes form, encounter actions
- Patient-history drawer and prescription navigation

**Mobile structure:**
- Video primary, patient ID visible
- Call controls reachable and accessible
- Clinical tabs open full-screen sheets

**Required real information:** Authorized appointment, real video session, device permissions, consent, notes, clinical context.
**Primary action:** Start/Resume Consultation; Complete when eligible
**Secondary actions:** Mic/camera; history; note draft; prescription; leave/reconnect.
**Connected workflow:** Queue -> Check eligibility + consent -> Join -> Assess + document -> Prescription optional -> Finish -> Queue.

| UX state / constraint | Specification |
|---|---|
| Loading | Device checks, joining, connecting, reconnecting states. |
| Empty | Waiting for real participant or session provisioning, not fake live call. |
| Error | Permission denied, disconnected, invalid link, patient absent. |
| Permission | Assigned doctor and authorized patient; confirmed video booking and payment verified. |
| Postpone | Recording, transcription, group calls, translation, AI summary, screen share. |
| Never simulate | Fake connected status, participants, elapsed time, encryption, consent or clinical assessment. |

### D08 - Prescription builder
**Route:** `/doctor/consultations/:id/prescription` | **Role:** Authorized prescribing doctor | **Pattern:** Structured form + document preview
**Primary user goal:** Draft, review and appropriately issue prescriptions or advice.

**Desktop wireframe (editable text, conceptual)**
```text
[ENCOUNTER + PATIENT ID BANNER]
+---------------------------------+------------------+
| CLINICAL FORM                   | DOCUMENT PREVIEW |
| Assessment/diagnosis            | Paper layout     |
| Medicine #1: name, dose, route  | Live draft only  |
| Frequency/duration              | Patient + doctor |
| [+ Add medicine]                | actual fields    |
| Investigations/advice/follow-up | No fake signing  |
+---------------------------------+------------------+
[Save Draft] [Review] [Issue if backend supports it]
```

**Desktop content order:**
- Encounter and patient identity banner
- Left form: assessment, diagnosis, medication rows, investigations, advice, follow-up
- Repeatable medicine input: name, strength, dose, route, frequency, duration
- Right synchronized prescription preview
- Sticky Save Draft / Review & Issue controls

**Mobile structure:**
- One-column medicine cards
- Preview as separate step
- Explicit final review before issuance

**Required real information:** Patient/doctor/encounter, clinical assessments, medication details, advice, issuance capability.
**Primary action:** Review & Issue (if implemented and authorized)
**Secondary actions:** Save draft; add/remove medicine; preview; return to encounter.
**Connected workflow:** Consultation -> Assessment -> Medication optional -> Preview -> Doctor review -> Actual issue -> Patient authorized record.

| UX state / constraint | Specification |
|---|---|
| Loading | Draft save, document generation and issuance progress. |
| Empty | No medication is valid; consultation can complete without Rx. |
| Error | Incomplete required data, save failure, issuance failure; preserve draft. |
| Permission | Assigned authorized doctor only; patient sees only genuinely issued records. |
| Postpone | AI prescribing, pharmacy integration, interaction checking, QR, digital signatures unless real. |
| Never simulate | Fake signature, QR, legally issued Rx, medication safety validation. |

### D09 - Doctor earnings
**Route:** `/doctor/earnings` | **Role:** Verified doctor; authorized finance roles separately | **Pattern:** Financial KPI cards + chart + transaction ledger
**Primary user goal:** Understand actual collections, adjustments and amount due.

**Desktop wireframe (editable text, conceptual)**
```text
[DOCTOR SHELL | Earnings | Date range / Export]
[Booked Fees][Collected][Deductions][Net Payable]
+----------------------------------+----------------+
| REVENUE CHART (actual data)      | BREAKDOWN      |
| Daily / weekly / monthly trend   | Chamber/Video  |
|                                  | Refunds etc.   |
+----------------------------------+----------------+
| TRANSACTION LEDGER                                |
| Date | Appointment | Amount | Status | Details     |
| [Filters] [Pagination] [Real statement export]     |
+---------------------------------------------------+
```

**Desktop content order:**
- Doctor shell + date range and export
- KPI cards: Booked Fees, Collected, Deductions, Net Payable
- Actual collection trend bar/line chart when data exists
- Breakdown panel: chamber/video/refunds/settlements
- Transaction table with filters, status and pagination

**Mobile structure:**
- KPIs stacked/two columns
- Expandable chart (optional)
- Transaction cards and filters drawer

**Required real information:** Real booking fee records, verified payment/collection, commissions, refund and settlement data.
**Primary action:** View Transaction Details
**Secondary actions:** Filter; inspect adjustments; export actual statement.
**Connected workflow:** Earnings -> Date range -> Transaction list -> Drill-down -> Real statement if supported.

| UX state / constraint | Specification |
|---|---|
| Loading | Totals and transaction list load independently. |
| Empty | No recorded transactions for date range. |
| Error | Ledger error, reconciliation pending, inaccurate settlement. |
| Permission | Doctor sees own earnings. Finance roles need explicit authorization. |
| Postpone | Forecasting, tax automation, payouts, profitability benchmarking. |
| Never simulate | Fake revenues, COD collection, bank transfer or payout completion. |

## 6. Supporting pages
| Page | Layout skeleton | User journey |
|---|---|---|
| S01 - Sign In / Register | Minimal header -> sign-in form -> recovery/help -> return destination | Authenticate and resume booking or onboarding without losing context. |
| S02 - Family Member Selection | Booking header -> self/family cards -> add person form -> continue | Pick the real patient and validate representative authority. |
| S03 - Video Payment | Minimal checkout -> actual payment choices -> fee summary -> authoritative status | Initiate payment, verify server-side and finalize booking only on success. |
| S04 - Booking Confirmation | Status heading -> verified booking card -> address/video instructions -> action buttons | View confirmed appointment and go to My Appointments. |
| S05 - My Appointments | Patient account nav -> Upcoming/Past/Cancelled -> appointment cards -> detail/actions | View and manage authorized bookings; join eligible live video. |
| S06 - Family Management | Account sidebar -> family list/cards -> add/edit -> permission notices | Manage family/dependent information with appropriate authorization. |
| S07 - Patient Records | Account header -> encounter tabs -> issued prescriptions -> document viewer | Read only own or otherwise authorized clinical records. |
| S08 - Patient Video Waiting Room | Appointment identity -> device test -> real consent -> join controls | Join confirmed, paid eligible appointment with actual video service. |
| S09 - Admin Verification Review | Admin nav -> applicant queue -> submitted documents -> decision panel | Review physician evidence and issue real approve/return/reject decision. |
| S10 - Account Settings | Account nav -> profile/security -> language/theme (after login) -> notification prefs | Manage real account preferences and security. |
| S11 - Doctor Verification Status | Applicant header -> status banner -> application summary -> correction requests | Track actual application decision and resubmit fixes. |
| S12 - Help & Support | Help nav -> FAQ -> issue categories -> contact/ticket history | Recover from booking, payment, profile or technical issues. |

Additional UX rules: Patient My Appointments uses Upcoming / Past / Cancelled tabs, cards and contextual management actions. The Patient Waiting Room includes real device testing, consent and eligible join action. Admin Verification Review contains professional evidence and reasons for real decisions, **not** clinical patient notes.

## 7. Navigation and connected workflow contract
| From | Action | Destination/behavior |
|---|---|---|
| Homepage | Find Doctors | P01 |
| Homepage | Choose specialty | P01 prefiltered |
| P01 | Open result | P02 |
| P02 | Select appointment | P03 |
| P03 | Backend hold succeeds | Authenticate if needed; preserve and revalidate |
| Booking | Choose self/family | S02 |
| Booking - chamber | Confirm | S04 only after commit |
| Booking - video | Pay | S03; server verification; then S04 |
| S04 | View appointment | S05 |
| S05 | Join eligible video | S08 then actual call |
| Doctor onboarding | Submit | S11 status |
| Admin review | Approve/return/reject | Actual applicant status update |
| D02 Profile | Set availability | D03 |
| D04 Today | Open queue | D05 |
| D05 Queue | Start valid appointment | D07 |
| D07 Consultation | Open history | D06 drawer |
| D07 Consultation | Prescribe | D08 |
| D08 Prescription | Return | D07 after draft/issue |
| D07 Consultation | Complete | D05 or D04 |
| D04 Today | View earnings | D09 |

## 8. Layout and domain component inventory
| Layout components | Purpose |
|---|---|
| PublicLayout | Header + public content + footer |
| BookingLayout | Minimal header + stepper + summary |
| PatientLayout | Authenticated patient navigation |
| DoctorLayout | Sidebar + utility bar + workspace |
| AdminLayout | Restricted review/navigation |
| PageHeader / PageContainer | Consistent content hierarchy and widths |
| DetailDrawer / FormSection | Contextual details and grouped form inputs |
| Skeleton / EmptyState / ErrorState | Data feedback and recovery |

**Domain components:** DoctorCard, DoctorIdentityHeader, AvailabilityPicker, BookingSummaryCard, FamilyMemberCard, AppointmentCard, AppointmentStatusChip, ChamberCard, WeeklySchedule, LeaveRequestForm, VerificationDocumentCard, PatientHistoryDrawer, ClinicalNoteEditor, MedicationRow, PrescriptionPreview, EarningsSummaryCard, TransactionLedger.

## 9. Responsive guidance
| Pattern | Desktop | Mobile |
|---|---|---|
| Public header | 64-72px horizontal navbar | Compact logo + menu drawer |
| Content width | Up to about 1240px | 16-20px side gutters |
| Doctor navigation | ~232-256px sidebar | Top utility header + drawer |
| Directory | ~240-280px filters at left | Filter drawer + card results |
| Doctor profile | Main content + ~340-380px booking panel | One column + bottom CTA |
| Booking | Form + summary side card | Guided steps + collapsible summary |
| Dashboard | 3-4 KPI cards per row | 1-2 cards per row |
| Queue | Timeline/table and detail panel | Appointment cards + detail sheet |
| Consultation | Video and clinical split screen | Video + clinical panels |
| Prescription | Form and document preview | Sequential form + separate preview |
| Earnings | KPI cards + chart + ledger | KPI cards + optional chart + transaction cards |

## 10. Which component to use where
| Element | Use | Avoid |
|---|---|---|
| Doctor cards | Directory/specialties | Clinical form |
| Booking summary | Booking/payment | Doctor note form |
| KPI cards | Today/Earnings | Every marketing page |
| Actual-data chart | Earnings | Patient-history drawer |
| Table | Desktop queue or ledger | Mobile doctor directory |
| Calendar | Availability/schedules/leave | Transaction details |
| Drawer | Filters, queue details, history | Long onboarding |
| Modal | Cancellation/discard/issuance | Large registration forms |
| Stepper | Booking/verification | Directory browsing |
| Toast | Routine noncritical save | Clinical/payment finality |

## 11. States and status modeling
Every API-backed page has Loading, Empty, Error and Unauthorized states. Critical actions need Pending and Confirmed/Fallback states. Never show an unknown amount as zero.

**Booking statuses:** Available -> Hold Requested -> Held -> Authentication/Patient -> Chamber Confirmation OR Video Payment Pending -> Confirmation Pending -> Confirmed -> Completed/Cancelled/No-show (according to real transitions). Hold Expired and Slot Conflict are recoverable branches.

**Doctor verification:** Draft -> Submitted -> Under Review -> Approved -> Published; Changes Requested and Rejected branch from review. Verification approval and public publication are distinct.

**Prescription:** Not Started -> Draft -> Doctor Review -> Issued -> Accessible to authorized patient. Draft-only if real issuance and signing rules are not implemented.

**Permissions:** Visitors discover; patients book their own or authorized family care; doctors access assigned clinical encounters; admin verifies doctors and manages operational metadata, not patient clinical notes.

## 12. Suggested Figma organization
- **00 Foundations:** Colors, typography, spacing, icon scale, accessibility
- **01 Components:** Buttons, fields, cards, tabs, tables, drawers and dialogs
- **02 Public:** Homepage, directory, doctor profile and specialties
- **03 Patient:** Authentication, booking, family, appointments and payments
- **04 Doctor Onboarding:** Verification and profile setup
- **05 Doctor Operations:** Dashboard, queue, schedules and leave
- **06 Clinical:** History, video session, notes and prescription
- **07 Finance:** Earnings, transactions and statements
- **08 Admin:** Credential review and restricted operations
- **09 Responsive:** Desktop/tablet/mobile variants
- **10 States and Prototypes:** Loading/empty/error, authorization and wired navigation

## 13. Recommended sequencing
1. **Discovery:** Directory -> doctor profile -> real availability picker.
2. **Booking:** Stepper -> login continuation -> family choice -> verified payment -> confirmation.
3. **Practice management:** Verification -> profile/chambers -> schedule/leave -> today/queue.
4. **Clinical workflow:** Restricted history -> actual consultation -> notes/prescription.
5. **Finance and quality:** Actual ledger/reconciliation, accessible responsive/error variants.

**Summary:** Three main UX patterns anchor the product: search-first public marketplace, guided appointment checkout and today-first doctor workspace. A large cart is unnecessary. Charts belong where they communicate actual financial data, not as decorative dashboard placeholders.
