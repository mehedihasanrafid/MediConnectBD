# MediConnectBD - Editable Page Skeletons Only
**Purpose:** Blank, editable content skeletons for desktop/mobile UX design. Replace every `[EDIT ...]` field with your own choices and API-backed information.

> These are **wireframe source templates**, not implementation-ready code or actual doctors/appointments. Text diagrams are editable in Markdown, DOCX and ODT.

## Global layout skeletons
### Public shell
```text
[LOGO] [FIND DOCTORS] [SPECIALTIES] [HOW IT WORKS] [HELP] [ACCOUNT]
[BREADCRUMBS / PAGE TITLE / OPTIONAL UTILITY ACTIONS]
[PAGE CONTENT AREA - EDIT]
[FOOTER: Navigation | Help | Policies]
```
### Booking shell
```text
[BACK] [LOGO]                         [HELP]
[STEP 1] -- [STEP 2] -- [STEP 3] -- [STEP 4]
+-------------------------------+-------------------+
| ACTIVE FORM / STEP            | BOOKING SUMMARY   |
| [EDIT FIELDS]                 | [EDIT ACTUAL DATA]|
| [CONTEXTUAL NEXT ACTION]      | [EDIT POLICY]     |
+-------------------------------+-------------------+
```
### Doctor shell
```text
[SIDEBAR TOGGLE] [PAGE TITLE] [UTILITY] [ACCOUNT]
+-----------------+---------------------------------+
| TODAY           | PAGE HEADER / ACTIONS           |
| APPOINTMENTS    |                                 |
| SCHEDULE        | [EDIT SCREEN CONTENT]           |
| CONSULTATIONS   |                                 |
| PRESCRIPTIONS   |                                 |
| EARNINGS        |                                 |
| PROFILE         |                                 |
| SETTINGS        |                                 |
+-----------------+---------------------------------+
```

## 12 core editable screen sheets
### P01 - Public doctor directory
**Route:** `/doctors`  
**Role:** Public  
**Designer / version:** [EDIT]  
**Primary goal:** [EDIT]  
**API data dependencies:** [EDIT]

**Desktop skeleton**
```text
[PUBLIC HEADER: Logo | Find Doctors | Specialties | Login]
[Breadcrumb] [Page Title]
[ Search doctor / specialty ][ Area ][ Search ]
[ Specialty chips ][ Chamber / Video ]
+------------------+----------------------------------+
| FILTERS          | Results # | Sort                 |
| Specialty        | +------------------------------+ |
| Area             | | Photo | Doctor summary       | |
| Mode             | |       | Fees / availability  | |
| Fee              | |       | View profile         | |
| Available date   | +------------------------------+ |
+------------------+----------------------------------+
[Pagination / Load More] [PUBLIC FOOTER]
```

**Mobile skeleton**
```text
[COMPACT HEADER / BACK / ACTION]
[PAGE TITLE + STATUS]
[PRIMARY CONTENT - ONE COLUMN]
[SECONDARY DETAILS - TABS / DRAWER / ACCORDION]
[CONTEXTUAL ACTION / BOTTOM SAFE AREA]
```

| Editable UX field | Your decision / content |
|---|---|
| Header and utilities | [EDIT] |
| Navbar / sidebar | [EDIT] |
| Page title and breadcrumb | [EDIT] |
| Cards and content order | [EDIT] |
| Filters / form inputs | [EDIT] |
| Graph / table / calendar (if appropriate) | [EDIT] |
| Primary CTA | [EDIT] |
| Secondary actions | [EDIT] |
| Modal / drawer behavior | [EDIT] |
| Loading skeleton | [EDIT] |
| Empty state | [EDIT] |
| Error state | [EDIT] |
| Authentication/permissions | [EDIT] |
| Postponed features | [EDIT] |
| Never present as real | [EDIT] |
| Next page / connection | [EDIT] |

**Suggested connection to edit:** Home/Search -> Filtered results -> Doctor card -> P02 Profile -> P03 Booking.

### P02 - Public doctor profile
**Route:** `/doctors/:id`  
**Role:** Public  
**Designer / version:** [EDIT]  
**Primary goal:** [EDIT]  
**API data dependencies:** [EDIT]

**Desktop skeleton**
```text
[PUBLIC HEADER] [Breadcrumb]
+--------------------------------+-------------------+
| Photo | Name, specialty        | BOOKING PANEL     |
| Qualifications & registration  | Chamber | Video   |
| [About][Credentials][Chambers] | Chamber selector  |
| Biography                      | Date picker       |
| Credentials                    | Actual slot chips |
| Chamber locations and fees     | Fee / policy      |
| Consultation policy            | [Continue]        |
+--------------------------------+-------------------+
[PUBLIC FOOTER]
```

**Mobile skeleton**
```text
[COMPACT HEADER / BACK / ACTION]
[PAGE TITLE + STATUS]
[PRIMARY CONTENT - ONE COLUMN]
[SECONDARY DETAILS - TABS / DRAWER / ACCORDION]
[CONTEXTUAL ACTION / BOTTOM SAFE AREA]
```

| Editable UX field | Your decision / content |
|---|---|
| Header and utilities | [EDIT] |
| Navbar / sidebar | [EDIT] |
| Page title and breadcrumb | [EDIT] |
| Cards and content order | [EDIT] |
| Filters / form inputs | [EDIT] |
| Graph / table / calendar (if appropriate) | [EDIT] |
| Primary CTA | [EDIT] |
| Secondary actions | [EDIT] |
| Modal / drawer behavior | [EDIT] |
| Loading skeleton | [EDIT] |
| Empty state | [EDIT] |
| Error state | [EDIT] |
| Authentication/permissions | [EDIT] |
| Postponed features | [EDIT] |
| Never present as real | [EDIT] |
| Next page / connection | [EDIT] |

**Suggested connection to edit:** P01 -> P02 -> Mode + location + date -> P03.

### P03 - Slot selection, booking and checkout
**Route:** `/booking/:doctorId`  
**Role:** Visitor then Patient  
**Designer / version:** [EDIT]  
**Primary goal:** [EDIT]  
**API data dependencies:** [EDIT]

**Desktop skeleton**
```text
[MINIMAL HEADER: Back | Logo | Help]
[1 Slot] -> [2 Sign in] -> [3 Patient] -> [4 Review]
+---------------------------------+-------------------+
| Mode: Chamber / Video           | BOOKING SUMMARY   |
| Choose chamber (when relevant)  | Doctor            |
| Date picker + real slots        | Date / time       |
| Hold state / expiry from server | Patient           |
| Sign in (if required)           | Charges / Total   |
| Self / Family selection         | Hold expiry       |
| Policy + confirmation           +-------------------+
| [Contextual Primary Action]                         |
+-----------------------------------------------------+
[Video requires verified payment before confirmation]
```

**Mobile skeleton**
```text
[COMPACT HEADER / BACK / ACTION]
[PAGE TITLE + STATUS]
[PRIMARY CONTENT - ONE COLUMN]
[SECONDARY DETAILS - TABS / DRAWER / ACCORDION]
[CONTEXTUAL ACTION / BOTTOM SAFE AREA]
```

| Editable UX field | Your decision / content |
|---|---|
| Header and utilities | [EDIT] |
| Navbar / sidebar | [EDIT] |
| Page title and breadcrumb | [EDIT] |
| Cards and content order | [EDIT] |
| Filters / form inputs | [EDIT] |
| Graph / table / calendar (if appropriate) | [EDIT] |
| Primary CTA | [EDIT] |
| Secondary actions | [EDIT] |
| Modal / drawer behavior | [EDIT] |
| Loading skeleton | [EDIT] |
| Empty state | [EDIT] |
| Error state | [EDIT] |
| Authentication/permissions | [EDIT] |
| Postponed features | [EDIT] |
| Never present as real | [EDIT] |
| Next page / connection | [EDIT] |

**Suggested connection to edit:** P02 -> Select slot -> Backend hold -> Sign in -> Select patient -> Chamber confirm OR Video verified payment -> Confirmation.

### D01 - Doctor registration and verification
**Route:** `/doctor/onboarding`  
**Role:** Doctor applicant  
**Designer / version:** [EDIT]  
**Primary goal:** [EDIT]  
**API data dependencies:** [EDIT]

**Desktop skeleton**
```text
[DOCTOR ONBOARDING HEADER | Save & Exit]
+-----------------+---------------------------------+
| STEP NAV        | CURRENT STEP FORM               |
| 1 Identity      | Full labels + validation         |
| 2 BMDC details  | BMDC registration data           |
| 3 Qualifications| Certificates upload             |
| 4 Certificates  | Review + declaration            |
| 5 Review        | [Back][Save][Continue/Submit]    |
+-----------------+---------------------------------+
[Status: Draft / Under Review / Changes / Approved]
```

**Mobile skeleton**
```text
[COMPACT HEADER / BACK / ACTION]
[PAGE TITLE + STATUS]
[PRIMARY CONTENT - ONE COLUMN]
[SECONDARY DETAILS - TABS / DRAWER / ACCORDION]
[CONTEXTUAL ACTION / BOTTOM SAFE AREA]
```

| Editable UX field | Your decision / content |
|---|---|
| Header and utilities | [EDIT] |
| Navbar / sidebar | [EDIT] |
| Page title and breadcrumb | [EDIT] |
| Cards and content order | [EDIT] |
| Filters / form inputs | [EDIT] |
| Graph / table / calendar (if appropriate) | [EDIT] |
| Primary CTA | [EDIT] |
| Secondary actions | [EDIT] |
| Modal / drawer behavior | [EDIT] |
| Loading skeleton | [EDIT] |
| Empty state | [EDIT] |
| Error state | [EDIT] |
| Authentication/permissions | [EDIT] |
| Postponed features | [EDIT] |
| Never present as real | [EDIT] |
| Next page / connection | [EDIT] |

**Suggested connection to edit:** Register -> Identity -> BMDC -> Certificates -> Review -> Submit -> Admin decision / correction request.

### D02 - Doctor profile and chamber setup
**Route:** `/doctor/profile`  
**Role:** Approved doctor or limited applicant draft  
**Designer / version:** [EDIT]  
**Primary goal:** [EDIT]  
**API data dependencies:** [EDIT]

**Desktop skeleton**
```text
[DOCTOR HEADER + LEFT MAIN SIDEBAR]
[Profile & Practice: Preview | Save]
+-------------+---------------------+--------------+
| SECTIONS    | EDITOR              | PREVIEW      |
| Profile     | Professional info   | Public card  |
| Credentials | Bio / specialties   | No publish   |
| Chambers    | Chamber repeaters   | claim until  |
| Video/Fees  | Addresses and fees  | approved     |
| Publication | [Add chamber]       |              |
+-------------+---------------------+--------------+
```

**Mobile skeleton**
```text
[COMPACT HEADER / BACK / ACTION]
[PAGE TITLE + STATUS]
[PRIMARY CONTENT - ONE COLUMN]
[SECONDARY DETAILS - TABS / DRAWER / ACCORDION]
[CONTEXTUAL ACTION / BOTTOM SAFE AREA]
```

| Editable UX field | Your decision / content |
|---|---|
| Header and utilities | [EDIT] |
| Navbar / sidebar | [EDIT] |
| Page title and breadcrumb | [EDIT] |
| Cards and content order | [EDIT] |
| Filters / form inputs | [EDIT] |
| Graph / table / calendar (if appropriate) | [EDIT] |
| Primary CTA | [EDIT] |
| Secondary actions | [EDIT] |
| Modal / drawer behavior | [EDIT] |
| Loading skeleton | [EDIT] |
| Empty state | [EDIT] |
| Error state | [EDIT] |
| Authentication/permissions | [EDIT] |
| Postponed features | [EDIT] |
| Never present as real | [EDIT] |
| Next page / connection | [EDIT] |

**Suggested connection to edit:** Approved practitioner -> Professional details -> Add chambers and modes -> Set fees -> D03 schedule -> Publish if eligible.

### D03 - Doctor schedule and leave management
**Route:** `/doctor/schedule`  
**Role:** Verified doctor  
**Designer / version:** [EDIT]  
**Primary goal:** [EDIT]  
**API data dependencies:** [EDIT]

**Desktop skeleton**
```text
[DOCTOR SHELL: Schedule | Save]
[Mode/Chamber][Week][Add hours][Add leave]
+----------------------------------+----------------+
| WEEK CALENDAR                    | RULE EDITOR    |
| Su Mo Tu We Th Fr Sa             | Shift hours    |
| [ ] [ ] [ ] [ ] [ ] [ ] [ ]       | Buffers        |
| [ ] [ ] [ ] [ ] [ ] [ ] [ ]       | Slot duration  |
| Working blocks (real data)       | Leave dates    |
| Existing booked appointment cues | Conflicts      |
+----------------------------------+----------------+
[Preview resulting slots] [Publish if valid]
```

**Mobile skeleton**
```text
[COMPACT HEADER / BACK / ACTION]
[PAGE TITLE + STATUS]
[PRIMARY CONTENT - ONE COLUMN]
[SECONDARY DETAILS - TABS / DRAWER / ACCORDION]
[CONTEXTUAL ACTION / BOTTOM SAFE AREA]
```

| Editable UX field | Your decision / content |
|---|---|
| Header and utilities | [EDIT] |
| Navbar / sidebar | [EDIT] |
| Page title and breadcrumb | [EDIT] |
| Cards and content order | [EDIT] |
| Filters / form inputs | [EDIT] |
| Graph / table / calendar (if appropriate) | [EDIT] |
| Primary CTA | [EDIT] |
| Secondary actions | [EDIT] |
| Modal / drawer behavior | [EDIT] |
| Loading skeleton | [EDIT] |
| Empty state | [EDIT] |
| Error state | [EDIT] |
| Authentication/permissions | [EDIT] |
| Postponed features | [EDIT] |
| Never present as real | [EDIT] |
| Next page / connection | [EDIT] |

**Suggested connection to edit:** Select chamber/mode -> Create hours -> Preview slots -> Resolve conflicts -> Publish -> Handle leave with affected-booking workflow.

### D04 - Doctor daily dashboard
**Route:** `/doctor/dashboard`  
**Role:** Verified doctor  
**Designer / version:** [EDIT]  
**Primary goal:** [EDIT]  
**API data dependencies:** [EDIT]

**Desktop skeleton**
```text
[DOCTOR SHELL | Today | Dhaka time]
[KPI Scheduled] [KPI Waiting] [KPI Done] [KPI Tasks]
+---------------------------------------------------+
| NEXT APPOINTMENT                                  |
| Actual patient, mode, time | [Open/Start]          |
+----------------------------------+----------------+
| TODAY'S QUEUE                    | NEEDS ATTENTION|
| Patient cards / time / status    | Notices        |
| [View all queue]                 | Pending tasks  |
+----------------------------------+----------------+
```

**Mobile skeleton**
```text
[COMPACT HEADER / BACK / ACTION]
[PAGE TITLE + STATUS]
[PRIMARY CONTENT - ONE COLUMN]
[SECONDARY DETAILS - TABS / DRAWER / ACCORDION]
[CONTEXTUAL ACTION / BOTTOM SAFE AREA]
```

| Editable UX field | Your decision / content |
|---|---|
| Header and utilities | [EDIT] |
| Navbar / sidebar | [EDIT] |
| Page title and breadcrumb | [EDIT] |
| Cards and content order | [EDIT] |
| Filters / form inputs | [EDIT] |
| Graph / table / calendar (if appropriate) | [EDIT] |
| Primary CTA | [EDIT] |
| Secondary actions | [EDIT] |
| Modal / drawer behavior | [EDIT] |
| Loading skeleton | [EDIT] |
| Empty state | [EDIT] |
| Error state | [EDIT] |
| Authentication/permissions | [EDIT] |
| Postponed features | [EDIT] |
| Never present as real | [EDIT] |
| Next page / connection | [EDIT] |

**Suggested connection to edit:** Login -> Today -> Next appointment -> Queue -> Consultation -> Today refreshed.

### D05 - Doctor appointment queue
**Route:** `/doctor/appointments`  
**Role:** Verified doctor  
**Designer / version:** [EDIT]  
**Primary goal:** [EDIT]  
**API data dependencies:** [EDIT]

**Desktop skeleton**
```text
[DOCTOR SHELL | Appointments | Date picker]
[All][Upcoming][Checked in][In progress][Completed]
[Search queue] [Mode filter]
+----------------------------------+----------------+
| CHRONOLOGICAL QUEUE              | DETAIL DRAWER  |
| Time | Patient | Mode | Status   | Identity       |
| Time | Patient | Mode | Status   | Status         |
| Time | Patient | Mode | Status   | Contextual CTA |
+----------------------------------+----------------+
```

**Mobile skeleton**
```text
[COMPACT HEADER / BACK / ACTION]
[PAGE TITLE + STATUS]
[PRIMARY CONTENT - ONE COLUMN]
[SECONDARY DETAILS - TABS / DRAWER / ACCORDION]
[CONTEXTUAL ACTION / BOTTOM SAFE AREA]
```

| Editable UX field | Your decision / content |
|---|---|
| Header and utilities | [EDIT] |
| Navbar / sidebar | [EDIT] |
| Page title and breadcrumb | [EDIT] |
| Cards and content order | [EDIT] |
| Filters / form inputs | [EDIT] |
| Graph / table / calendar (if appropriate) | [EDIT] |
| Primary CTA | [EDIT] |
| Secondary actions | [EDIT] |
| Modal / drawer behavior | [EDIT] |
| Loading skeleton | [EDIT] |
| Empty state | [EDIT] |
| Error state | [EDIT] |
| Authentication/permissions | [EDIT] |
| Postponed features | [EDIT] |
| Never present as real | [EDIT] |
| Next page / connection | [EDIT] |

**Suggested connection to edit:** Dashboard -> Filter queue -> Appointment details -> Eligible Start -> D07 Consultation -> Update state.

### D06 - Patient-history drawer
**Route:** `Context within /doctor/consultations/:id`  
**Role:** Authorized clinician  
**Designer / version:** [EDIT]  
**Primary goal:** [EDIT]  
**API data dependencies:** [EDIT]

**Desktop skeleton**
```text
[CONSULTATION VIEW: background]
                      +-----------------------------+
                      | PATIENT HISTORY [Close]     |
                      | Patient + encounter ID      |
                      | [Summary][Visits][Meds]     |
                      | [Allergies][Documents]      |
                      | Authorized record cards     |
                      | [Open detail]                |
                      +-----------------------------+
```

**Mobile skeleton**
```text
[COMPACT HEADER / BACK / ACTION]
[PAGE TITLE + STATUS]
[PRIMARY CONTENT - ONE COLUMN]
[SECONDARY DETAILS - TABS / DRAWER / ACCORDION]
[CONTEXTUAL ACTION / BOTTOM SAFE AREA]
```

| Editable UX field | Your decision / content |
|---|---|
| Header and utilities | [EDIT] |
| Navbar / sidebar | [EDIT] |
| Page title and breadcrumb | [EDIT] |
| Cards and content order | [EDIT] |
| Filters / form inputs | [EDIT] |
| Graph / table / calendar (if appropriate) | [EDIT] |
| Primary CTA | [EDIT] |
| Secondary actions | [EDIT] |
| Modal / drawer behavior | [EDIT] |
| Loading skeleton | [EDIT] |
| Empty state | [EDIT] |
| Error state | [EDIT] |
| Authentication/permissions | [EDIT] |
| Postponed features | [EDIT] |
| Never present as real | [EDIT] |
| Next page / connection | [EDIT] |

**Suggested connection to edit:** Authorized consultation -> Open history -> Verify scope -> Inspect records -> Close -> Continue notes.

### D07 - Video consultation workspace
**Route:** `/doctor/consultations/:id`  
**Role:** Assigned doctor; patient has own waiting/join UI  
**Designer / version:** [EDIT]  
**Primary goal:** [EDIT]  
**API data dependencies:** [EDIT]

**Desktop skeleton**
```text
[CONSULTATION HEADER: patient / mode / status]
+---------------------------------+------------------+
| VIDEO VIEW                      | CLINICAL PANEL   |
| Actual session / participant    | Notes | History  |
|                                 | Prescription     |
| [Mic][Camera][Audio][Hang up]   | Clinical form    |
| Connection and device state     | [Save Draft]     |
+---------------------------------+------------------+
[Complete encounter only on verified eligible state]
```

**Mobile skeleton**
```text
[COMPACT HEADER / BACK / ACTION]
[PAGE TITLE + STATUS]
[PRIMARY CONTENT - ONE COLUMN]
[SECONDARY DETAILS - TABS / DRAWER / ACCORDION]
[CONTEXTUAL ACTION / BOTTOM SAFE AREA]
```

| Editable UX field | Your decision / content |
|---|---|
| Header and utilities | [EDIT] |
| Navbar / sidebar | [EDIT] |
| Page title and breadcrumb | [EDIT] |
| Cards and content order | [EDIT] |
| Filters / form inputs | [EDIT] |
| Graph / table / calendar (if appropriate) | [EDIT] |
| Primary CTA | [EDIT] |
| Secondary actions | [EDIT] |
| Modal / drawer behavior | [EDIT] |
| Loading skeleton | [EDIT] |
| Empty state | [EDIT] |
| Error state | [EDIT] |
| Authentication/permissions | [EDIT] |
| Postponed features | [EDIT] |
| Never present as real | [EDIT] |
| Next page / connection | [EDIT] |

**Suggested connection to edit:** Queue -> Check eligibility + consent -> Join -> Assess + document -> Prescription optional -> Finish -> Queue.

### D08 - Prescription builder
**Route:** `/doctor/consultations/:id/prescription`  
**Role:** Authorized prescribing doctor  
**Designer / version:** [EDIT]  
**Primary goal:** [EDIT]  
**API data dependencies:** [EDIT]

**Desktop skeleton**
```text
[ENCOUNTER + PATIENT ID BANNER]
+---------------------------------+------------------+
| CLINICAL FORM                   | DOCUMENT PREVIEW |
| Assessment/diagnosis            | Paper layout     |
| Medicine #1: name, dose, route  | Live draft only  |
| Frequency/duration              | Patient + doctor |
| [+ Add medicine]                | actual fields    |
| Investigations/advice/follow-up | No fake signing  |
+---------------------------------+------------------+
[Save Draft] [Review] [Issue if backend supports it]
```

**Mobile skeleton**
```text
[COMPACT HEADER / BACK / ACTION]
[PAGE TITLE + STATUS]
[PRIMARY CONTENT - ONE COLUMN]
[SECONDARY DETAILS - TABS / DRAWER / ACCORDION]
[CONTEXTUAL ACTION / BOTTOM SAFE AREA]
```

| Editable UX field | Your decision / content |
|---|---|
| Header and utilities | [EDIT] |
| Navbar / sidebar | [EDIT] |
| Page title and breadcrumb | [EDIT] |
| Cards and content order | [EDIT] |
| Filters / form inputs | [EDIT] |
| Graph / table / calendar (if appropriate) | [EDIT] |
| Primary CTA | [EDIT] |
| Secondary actions | [EDIT] |
| Modal / drawer behavior | [EDIT] |
| Loading skeleton | [EDIT] |
| Empty state | [EDIT] |
| Error state | [EDIT] |
| Authentication/permissions | [EDIT] |
| Postponed features | [EDIT] |
| Never present as real | [EDIT] |
| Next page / connection | [EDIT] |

**Suggested connection to edit:** Consultation -> Assessment -> Medication optional -> Preview -> Doctor review -> Actual issue -> Patient authorized record.

### D09 - Doctor earnings
**Route:** `/doctor/earnings`  
**Role:** Verified doctor; authorized finance roles separately  
**Designer / version:** [EDIT]  
**Primary goal:** [EDIT]  
**API data dependencies:** [EDIT]

**Desktop skeleton**
```text
[DOCTOR SHELL | Earnings | Date range / Export]
[Booked Fees][Collected][Deductions][Net Payable]
+----------------------------------+----------------+
| REVENUE CHART (actual data)      | BREAKDOWN      |
| Daily / weekly / monthly trend   | Chamber/Video  |
|                                  | Refunds etc.   |
+----------------------------------+----------------+
| TRANSACTION LEDGER                                |
| Date | Appointment | Amount | Status | Details     |
| [Filters] [Pagination] [Real statement export]     |
+---------------------------------------------------+
```

**Mobile skeleton**
```text
[COMPACT HEADER / BACK / ACTION]
[PAGE TITLE + STATUS]
[PRIMARY CONTENT - ONE COLUMN]
[SECONDARY DETAILS - TABS / DRAWER / ACCORDION]
[CONTEXTUAL ACTION / BOTTOM SAFE AREA]
```

| Editable UX field | Your decision / content |
|---|---|
| Header and utilities | [EDIT] |
| Navbar / sidebar | [EDIT] |
| Page title and breadcrumb | [EDIT] |
| Cards and content order | [EDIT] |
| Filters / form inputs | [EDIT] |
| Graph / table / calendar (if appropriate) | [EDIT] |
| Primary CTA | [EDIT] |
| Secondary actions | [EDIT] |
| Modal / drawer behavior | [EDIT] |
| Loading skeleton | [EDIT] |
| Empty state | [EDIT] |
| Error state | [EDIT] |
| Authentication/permissions | [EDIT] |
| Postponed features | [EDIT] |
| Never present as real | [EDIT] |
| Next page / connection | [EDIT] |

**Suggested connection to edit:** Earnings -> Date range -> Transaction list -> Drill-down -> Real statement if supported.

## Supporting page skeletons
### S01 - Sign In / Register
```text
[HEADER / NAVIGATION]
[PAGE TITLE + CONTEXT]
[MAIN CARD / LIST / FORM]
[SECONDARY PANEL / MODAL - OPTIONAL]
[PRIMARY CTA + BACK / CANCEL]
[FOOTER OR ACCOUNT UTILITIES]
```
**Starting arrangement:** Minimal header -> sign-in form -> recovery/help -> return destination  
**To edit:** [Fields] [Actions] [API states] [Permissions] [Next page]

### S02 - Family Member Selection
```text
[HEADER / NAVIGATION]
[PAGE TITLE + CONTEXT]
[MAIN CARD / LIST / FORM]
[SECONDARY PANEL / MODAL - OPTIONAL]
[PRIMARY CTA + BACK / CANCEL]
[FOOTER OR ACCOUNT UTILITIES]
```
**Starting arrangement:** Booking header -> self/family cards -> add person form -> continue  
**To edit:** [Fields] [Actions] [API states] [Permissions] [Next page]

### S03 - Video Payment
```text
[HEADER / NAVIGATION]
[PAGE TITLE + CONTEXT]
[MAIN CARD / LIST / FORM]
[SECONDARY PANEL / MODAL - OPTIONAL]
[PRIMARY CTA + BACK / CANCEL]
[FOOTER OR ACCOUNT UTILITIES]
```
**Starting arrangement:** Minimal checkout -> actual payment choices -> fee summary -> authoritative status  
**To edit:** [Fields] [Actions] [API states] [Permissions] [Next page]

### S04 - Booking Confirmation
```text
[HEADER / NAVIGATION]
[PAGE TITLE + CONTEXT]
[MAIN CARD / LIST / FORM]
[SECONDARY PANEL / MODAL - OPTIONAL]
[PRIMARY CTA + BACK / CANCEL]
[FOOTER OR ACCOUNT UTILITIES]
```
**Starting arrangement:** Status heading -> verified booking card -> address/video instructions -> action buttons  
**To edit:** [Fields] [Actions] [API states] [Permissions] [Next page]

### S05 - My Appointments
```text
[HEADER / NAVIGATION]
[PAGE TITLE + CONTEXT]
[MAIN CARD / LIST / FORM]
[SECONDARY PANEL / MODAL - OPTIONAL]
[PRIMARY CTA + BACK / CANCEL]
[FOOTER OR ACCOUNT UTILITIES]
```
**Starting arrangement:** Patient account nav -> Upcoming/Past/Cancelled -> appointment cards -> detail/actions  
**To edit:** [Fields] [Actions] [API states] [Permissions] [Next page]

### S06 - Family Management
```text
[HEADER / NAVIGATION]
[PAGE TITLE + CONTEXT]
[MAIN CARD / LIST / FORM]
[SECONDARY PANEL / MODAL - OPTIONAL]
[PRIMARY CTA + BACK / CANCEL]
[FOOTER OR ACCOUNT UTILITIES]
```
**Starting arrangement:** Account sidebar -> family list/cards -> add/edit -> permission notices  
**To edit:** [Fields] [Actions] [API states] [Permissions] [Next page]

### S07 - Patient Records
```text
[HEADER / NAVIGATION]
[PAGE TITLE + CONTEXT]
[MAIN CARD / LIST / FORM]
[SECONDARY PANEL / MODAL - OPTIONAL]
[PRIMARY CTA + BACK / CANCEL]
[FOOTER OR ACCOUNT UTILITIES]
```
**Starting arrangement:** Account header -> encounter tabs -> issued prescriptions -> document viewer  
**To edit:** [Fields] [Actions] [API states] [Permissions] [Next page]

### S08 - Patient Video Waiting Room
```text
[HEADER / NAVIGATION]
[PAGE TITLE + CONTEXT]
[MAIN CARD / LIST / FORM]
[SECONDARY PANEL / MODAL - OPTIONAL]
[PRIMARY CTA + BACK / CANCEL]
[FOOTER OR ACCOUNT UTILITIES]
```
**Starting arrangement:** Appointment identity -> device test -> real consent -> join controls  
**To edit:** [Fields] [Actions] [API states] [Permissions] [Next page]

### S09 - Admin Verification Review
```text
[HEADER / NAVIGATION]
[PAGE TITLE + CONTEXT]
[MAIN CARD / LIST / FORM]
[SECONDARY PANEL / MODAL - OPTIONAL]
[PRIMARY CTA + BACK / CANCEL]
[FOOTER OR ACCOUNT UTILITIES]
```
**Starting arrangement:** Admin nav -> applicant queue -> submitted documents -> decision panel  
**To edit:** [Fields] [Actions] [API states] [Permissions] [Next page]

### S10 - Account Settings
```text
[HEADER / NAVIGATION]
[PAGE TITLE + CONTEXT]
[MAIN CARD / LIST / FORM]
[SECONDARY PANEL / MODAL - OPTIONAL]
[PRIMARY CTA + BACK / CANCEL]
[FOOTER OR ACCOUNT UTILITIES]
```
**Starting arrangement:** Account nav -> profile/security -> language/theme (after login) -> notification prefs  
**To edit:** [Fields] [Actions] [API states] [Permissions] [Next page]

### S11 - Doctor Verification Status
```text
[HEADER / NAVIGATION]
[PAGE TITLE + CONTEXT]
[MAIN CARD / LIST / FORM]
[SECONDARY PANEL / MODAL - OPTIONAL]
[PRIMARY CTA + BACK / CANCEL]
[FOOTER OR ACCOUNT UTILITIES]
```
**Starting arrangement:** Applicant header -> status banner -> application summary -> correction requests  
**To edit:** [Fields] [Actions] [API states] [Permissions] [Next page]

### S12 - Help & Support
```text
[HEADER / NAVIGATION]
[PAGE TITLE + CONTEXT]
[MAIN CARD / LIST / FORM]
[SECONDARY PANEL / MODAL - OPTIONAL]
[PRIMARY CTA + BACK / CANCEL]
[FOOTER OR ACCOUNT UTILITIES]
```
**Starting arrangement:** Help nav -> FAQ -> issue categories -> contact/ticket history  
**To edit:** [Fields] [Actions] [API states] [Permissions] [Next page]

## Shared blank component checklist
- [ ] PublicHeader + MobileMenu
- [ ] DoctorSidebar + UtilityHeader
- [ ] BookingStepper + BookingSummary
- [ ] DoctorCard + AvailabilityPicker
- [ ] FamilyMemberSelector
- [ ] AppointmentRow + StatusChip
- [ ] VerificationUpload + ReviewStatus
- [ ] CalendarWeek + LeaveDialog
- [ ] PatientHistoryDrawer
- [ ] VideoPanel + ClinicalNotes
- [ ] MedicationRow + PrescriptionPreview
- [ ] EarningsKPI + Chart + Ledger
- [ ] Loading/Empty/Error/Unauthorized states

## Blank connection map
```text
HOME -> [EDIT] -> DIRECTORY -> [EDIT] -> DOCTOR PROFILE
PROFILE -> SLOT -> HOLD -> LOGIN -> FAMILY -> REVIEW
REVIEW -> CHAMBER CONFIRM | VIDEO VERIFIED PAYMENT
CONFIRMED -> PATIENT APPOINTMENTS -> CONSULTATION -> RECORDS
DOCTOR REGISTRATION -> VERIFICATION -> PROFILE -> SCHEDULE
DASHBOARD -> QUEUE -> CONSULTATION -> HISTORY / RX -> COMPLETE
EARNINGS <- ACTUAL TRANSACTION LEDGER
```
