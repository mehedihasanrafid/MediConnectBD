# MediConnectBD UX Design Pack

This ZIP contains **two independent document sets** in each of four formats: Markdown (`.md`), editable Word (`.docx`), editable OpenDocument Text (`.odt`), and PDF (`.pdf`).

## 01_Full_UX_Blueprint

Comprehensive written specification of the previous response: architecture, headers, navigation, reusable components, all 12 core screens, desktop wireframe placeholders, mobile variants, workflow connections, necessary supporting pages, states, permission design, responsive guidelines and recommended design order.

## 02_Editable_Skeletons_Only

A stripped-down, **editable** template containing text-based wireframes for all 12 core screens plus 12 supporting pages and blank `[EDIT]` cells for your design choices. This is the best file to change directly.

## Which file to use

- **Edit text and wireframes:** `02_Editable_Skeletons_Only/*.md`, `.docx` or `.odt`.
- **Read/print:** `.pdf`.
- **Read the full design reasoning:** `01_Full_UX_Blueprint/*`.

All doctor/patient/appointment examples are placeholders. No UI, backend feature, clinical capability, payment success or medical credential is claimed to exist just because its skeleton appears here.
